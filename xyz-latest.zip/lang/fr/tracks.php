<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Track-related Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are related to track feature.
    |
    */

    'likes' => ':count j\'aime',
    'count' => '[0,1] :count titre|[2,*] :count titres',
    'posts' => '[0,1] :count contribution|[2,*] :count contributions',
    'remaining' => '[0,1] :count contribution restante|[2,*] :count contributions restantes',

];
