<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Track-related Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are related to track feature.
    |
    */

    'count' => '[0,1] :count track|[2,*] :count tracks',
    'posts' => '[0,1] :count post|[2,*] :count posts',
    'remaining' => '[0,1] :count remaining post|[2,*] :count remaining posts',

];
