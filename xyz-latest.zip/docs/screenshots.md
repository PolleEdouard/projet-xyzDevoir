# XYZ

## Captures d'écran

#### Connexion

<img src="screenshots/auth.png" alt="Connexion" />

#### Inscription (étape 1)

<img src="screenshots/signup-1.png" alt="Inscription (étape 1)" />

#### Inscription (étape 2)

<img src="screenshots/signup-2.png" alt="Inscription (étape 2)" />

#### Page d'accueil

<img src="screenshots/home.png" alt="Page d'accueil" />

#### Classement

<img src="screenshots/week.png" alt="Classement" />

#### Contribution

<img src="screenshots/track.png" alt="Contribution" />

#### Nouvelle contribution

<img src="screenshots/create.png" alt="Nouvelle contribution" />

#### Profil

<img src="screenshots/profile.png" alt="Profil" />