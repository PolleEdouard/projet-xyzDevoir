<x-app title="403 Unauthorized">

    <main class="container-wide space-y-8" style="flex-grow: 1; align-content: center; text-align: center;">
        <h1>403 Unauthorized</h1>
    </main>

</x-app>