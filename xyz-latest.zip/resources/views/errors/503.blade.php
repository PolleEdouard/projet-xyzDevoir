<x-app title="503 Maintenance">

    <main class="container-wide space-y-8" style="flex-grow: 1; align-content: center; text-align: center;">
        <h1>503 Maintenance</h1>
    </main>

</x-app>