<x-app title="404 Not Found">

    <main class="container-wide space-y-8" style="flex-grow: 1; align-content: center; text-align: center;">
        <h1>404 Not Found</h1>
    </main>

</x-app>