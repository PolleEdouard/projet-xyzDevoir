<x-app title="500 Server Error">

    <main class="container-wide space-y-8" style="flex-grow: 1; align-content: center; text-align: center;">
        <h1>500 Server Error</h1>
    </main>

</x-app>