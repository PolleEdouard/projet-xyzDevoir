<x-app title="419 Page Expired">

    <main class="container-wide space-y-8" style="flex-grow: 1; align-content: center; text-align: center;">
        <h1>419 Page Expired</h1>
    </main>

</x-app>